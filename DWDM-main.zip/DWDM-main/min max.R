numbers <- c(2,4,6,8,10)
print(min(numbers))
print(max(numbers))
