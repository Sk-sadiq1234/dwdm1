V<-c(9,13,21,8,36,22,12,41,31,33,19)
png(file="histogram.png")
hist(V,xlab="weight",col="yellow",border="blue")
dev.off()