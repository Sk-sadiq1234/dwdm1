n1=as.integer(readline(prompt="enter number:"))
print(sqrt(n1))