x<-c(12,7,3,4.2,18,2,54,-21,8,-5)
result.mean<-mean(x)
print(result.mean)
