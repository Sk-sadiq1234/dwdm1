png(file="boxplot.png")
boxplot(mpg~cyl,data=mtcars,xlab="number of cylinders",ylab="miles per gallon",main="mileage data")
dev.off()