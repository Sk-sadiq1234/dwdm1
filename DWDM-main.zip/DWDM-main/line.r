V<-c(7,12,28,3,41)
png(file="line_chart.jpg")
plot(V,type="o")
dev.off()