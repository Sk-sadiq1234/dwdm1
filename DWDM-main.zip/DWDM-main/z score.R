data <- c(6, 7, 7, 12, 13, 13, 15, 16, 19, 22)
z_scores <- (data-mean(data))/sd(data)
z_scores
