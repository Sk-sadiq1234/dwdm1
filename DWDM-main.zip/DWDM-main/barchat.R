H<-c(7,12,28,3,41)
png(file="barchart.png")
barplot(H)
dev.off()