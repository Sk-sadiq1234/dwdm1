num1=as.integer(readline(prompt="enter a number1:"))
num2=as.integer(readline(prompt="enter a number2:"))
num3=num1/num2
print(num3)
