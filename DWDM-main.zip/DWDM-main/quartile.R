x = c(2,13,5,36,12,50)
res<-quantile(x, probs = c(0,0.25,0.5,0.75,1))
res
