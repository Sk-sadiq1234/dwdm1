num=as.integer(readline(prompt="enter a number:"))
if((num%%2)==0){
  print('number is even')
}else{
  print('number is odd')
}
